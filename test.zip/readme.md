# SeatGeek challenge

I decided to write a small node.js server using all the libraries from standard library. Tests are written in Jest though, so you need to install with:

```npm install```

## Running tests

```npm test```

## Running the server

```npm start```
