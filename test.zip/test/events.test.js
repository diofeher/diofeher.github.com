const events = require('../src/events');
// Test 2: Test order of events
describe('events', () => {
  it('test if query is working as expected', () => {
    const response1 = events.query("A10");
    expect(response1).toEqual("FREE");

    const response2 = events.reserve("A10");
    expect(response2).toEqual("OK");

    const response3 = events.query("A10");
    expect(response3).toEqual("RESERVED");

    const response4 = events.query("A11");
    expect(response4).toEqual("FREE");
  });

  it('test if reserve is working as expected', () => {
    const response1 = events.reserve("A10");
    expect(response1).toEqual("OK");

    const response2 = events.reserve("A10");
    expect(response2).toEqual("FAIL");
  });

  it('test if buy is working as expected', () => {
    const response1 = events.buy("A11");
    expect(response1).toEqual("FAIL");

    const response2 = events.buy("A10");
    expect(response2).toEqual("FAIL");
  });

  beforeEach(() => {
    events.resetSeats();
    jest.clearAllMocks();
  });
});
