// Test 2: Test order of events
const dispatch = require('../src/dispatch');
const exceptions = require('../src/exceptions');

describe('dispatch', () => {
  it('test if handle raises when msg is invalid', () => {
    expect(() => {
      dispatch.handle("BU: A123");
    }).toThrow(exceptions.InvalidCommandException);
  });

  it('test if handle raises when msg is empty', () => {
    expect(() => {
      dispatch.handle("");
    }).toThrow(exceptions.EmptyMessageException);
  });

  it('test if handle raises when seat is invalid', () => {
    expect(() => {
      dispatch.handle("BUY: A1-23")
    }).toThrow(exceptions.InvalidSeatException);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });
})
