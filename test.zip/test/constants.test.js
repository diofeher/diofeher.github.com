// Test 2: Test order of events
const { STATE, STATE_REVERSE } = require('../src/constants');

describe('state', () => {
  it('test if reserved association is right', () => {
    const st = STATE.RESERVED;
    expect('RESERVED').toEqual(STATE_REVERSE[st]);
  });

  it('test if free association is right', () => {
    const st = STATE.FREE;
    expect('FREE').toEqual(STATE_REVERSE[st]);
  });

  it('test if sold association is right', () => {
    const st = STATE.SOLD;
    expect('SOLD').toEqual(STATE_REVERSE[st]);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });
})
