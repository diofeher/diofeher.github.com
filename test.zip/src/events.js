
const dispatch = require('./dispatch');
const { STATUS, STATE, STATE_REVERSE } = require('./constants');

var SEATS = {};

const getState = (state) => {
  return STATE_REVERSE[state];
}

const query = (seat) => {
  if(seat in SEATS) {
    return getState(SEATS[seat]);
  }

  SEATS[seat] = STATE.FREE;
  return STATUS.FREE;
}

const reserve = (seat) => {
  if(!(seat in SEATS) || SEATS[seat] == STATE.FREE) {
    SEATS[seat] = STATE.RESERVED;
    return STATUS.OK;
  }
  return STATUS.FAIL;
};

const buy = (seat) => {
  if(SEATS[seat] && SEATS[seat] == STATE.RESERVED) {
    SEATS[seat] = STATE.SOLD;
    return STATUS.OK;
  }

  return STATUS.FAIL;
};

const resetSeats = () => {
  SEATS = {};
}

exports.query = query;
exports.reserve = reserve;
exports.buy = buy;
exports.resetSeats = resetSeats;
