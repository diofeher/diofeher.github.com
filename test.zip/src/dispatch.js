const exceptions = require('./exceptions');
const events = require('./events');
const { EVENTS, VALID_EVENTS } = require('./constants');

const handle = (msg) => {
  const [msgType, seatDirty] = msg.split(':');
  const seat = (seatDirty || "").trim();

  if(msgType == "" || seat == "") {
    throw new exceptions.EmptyMessageTypeException(msgType);
  };

  if(!VALID_EVENTS.includes(msgType)) {
    throw new exceptions.InvalidCommandException(msgType);
  };

  if(!seat.match(/^[0-9a-zA-Z]+$/)) {
    throw new exceptions.InvalidSeatException(msgType);
  }

  return dispatch(msg);
}

const dispatch = (msg) => {
  const [msgTypeText, seatDirty] = msg.split(':');
  const seat = seatDirty.trim();
  const msgType = EVENTS[msgTypeText];

  switch(msgType) {
    case EVENTS.QUERY: return events.query(seat);
    case EVENTS.RESERVE: return events.reserve(seat);
    case EVENTS.BUY: return events.buy(seat);
    default: throw new exceptions.InvalidCommandException(msgType);
  };
}

exports.handle = handle
exports.dispatch = dispatch
