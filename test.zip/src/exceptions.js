class InvalidCommandException extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = 'InvalidCommandException';
  }
}

class EmptyMessageTypeException extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = 'EmptyMessageException';
  }
}

class InvalidSeatException extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = 'InvalidSeatException';
  }
}

module.exports = {
  'InvalidCommandException': InvalidCommandException,
  'EmptyMessageTypeException': EmptyMessageTypeException,
  'InvalidSeatException': InvalidSeatException,
}
