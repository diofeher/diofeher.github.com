const EVENTS = {
  RESERVE: 1,
  BUY: 2,
  QUERY: 3,
};

const VALID_EVENTS = Object.keys(EVENTS);

const STATUS = {
  FREE: 'FREE',
  OK: 'OK',
  FAIL: 'FAIL',
}

const STATE = {
  RESERVED: 1,
  FREE: 2,
  SOLD: 3,
}

const STATE_REVERSE = {
  '1': 'RESERVED',
  '2': 'FREE',
  '3': 'SOLD',
}


module.exports = {
  "STATE": STATE,
  "EVENTS": EVENTS,
  "STATUS": STATUS,
  "STATE_REVERSE": STATE_REVERSE,
  "VALID_EVENTS": VALID_EVENTS,
}
