const net = require('net');
const readline = require('readline');
const dispatch = require('./dispatch');

const server = net.createServer();


server.on('connection', (sock) => {
  let rl = readline.createInterface(sock, sock)
  rl.on('line', (line) => {
    try {
      if(!line) { return }
      const response = dispatch.handle(line);
      sock.write(response + "\n");
    } catch(e) {
      // TODO: Robust log handling
      console.error(line, e);
      sock.write("FAIL\n");
    }
  });

  sock.on('error', (_) => {
    sock.write("FAIL\n");
  });

  sock.on('close', (_) => {
  })
});


const host = process.env.HOST || '127.0.0.1'
const port = process.env.EVENT_SOURCE_PORT || 8099

server.listen(port, host, () => {
  console.log(`Tcp server is running on ${host}:${port}...`)
});
